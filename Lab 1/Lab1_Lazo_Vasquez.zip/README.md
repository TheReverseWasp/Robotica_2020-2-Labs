## Explicación de la tarea

Github: https://github.com/TheReverseWasp/Robotica_2020-2-Labs

1. La distribución (Gauss, triangular) se hace más notoria a medida que aumentan las iteraciones a considerar; es decir se hace más parecida a la original.
2. En el caso de la distribución de Gauss si se aumentan los puntos a considerar (de 12 a 20) la campana se alarga horizontalmente (detalle a esperarse por ser un valor multiplicativo).
3. Los resultados están en la carpeta "./Lab1" Donde se encuentra el código, los resultados para 10k iteraciones, los resultados para 100k iteraciones y para listas de 12 a 20 puntos (Gauss horizontal).


